import { combineReducers } from 'redux'
import book from './books-reducer'

export default combineReducers({
	book
})