import React, { Component } from 'react'

class WidgetList extends Component {
  render() {
    return (
      <div>
        <header>
          <h1>A list of widgets</h1>
        </header>
      </div>
    )
  }
}

export default WidgetList