import { combineReducers } from 'redux'
import widgets from './widgets'

const widgetApp = combineReducers({
  widgets
})

export default widgetApp
