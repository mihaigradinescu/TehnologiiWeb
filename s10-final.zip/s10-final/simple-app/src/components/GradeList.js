import React, { Component } from 'react'
import Grade from './Grade'
import GradeForm from './GradeForm'
import GradeStore from '../stores/GradeStore'

class GradeList extends Component {
  constructor(props){
    super(props)
    this.state = {
      grades : []
    }
    this.store = new GradeStore()
    this.add = (grade) => {
      this.store.addOne(this.props.item.id, grade)
    }
    this.delete = (gradeId) => {
      this.store.deleteOne(this.props.item.id, gradeId)
    }
    this.save = (gradeId, grade) => {
      this.store.saveOne(this.props.item.id, gradeId, grade)
    }
  }
  componentDidMount(){
    this.store.getAll(this.props.item.id)
    this.store.emitter.addListener('GET_ALL_SUCCESS', () => {
      this.setState({
        grades : this.store.content
      })
    })
  }
  render() {
    return (
      <div>
        <div>
          I will be the grade list for {this.props.item.firstName}
        </div>
        <div>
          {this.state.grades.map((e, i) => <Grade item={e} key={i} onDelete={this.delete} onSave={this.save} />)}
        </div>
        <div>
          <GradeForm onAdd={this.add} />
        </div>
      </div>
    )
  }
}

export default GradeList
