import React, { Component } from 'react';
import StudentList from './StudentList'

class App extends Component {
  render() {
    return (
      <div>
        <StudentList />
      </div>
    )
  }
}

export default App
