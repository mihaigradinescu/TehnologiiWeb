import React, { Component } from 'react';

class StudentDetails extends Component {
  render() {
    return (
      <div>
        I will show the grades for {this.props.item.firstName}
        <input type="button" value="back" onClick={() => this.props.onExit()}/>
      </div>
    )
  }
}

export default StudentDetails
