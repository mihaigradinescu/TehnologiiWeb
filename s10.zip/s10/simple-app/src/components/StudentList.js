import React, { Component } from 'react';
import StudentStore from '../stores/StudentStore'
import Student from './Student'
import StudentForm from './StudentForm'
import StudentDetails from './StudentDetails'

class StudentList extends Component {
  constructor(){
    super()
    this.state = {
      students : [],
      detailsFor : -1,
      selectedStudent : null
    }
    this.store = new StudentStore()
    this.add = (student) => {
      this.store.addOne(student)
    }
    this.delete = (id) => {
      this.store.deleteOne(id)
    }
    this.save = (id, student) => {
      this.store.saveOne(id, student)
    }
    this.select = (id) => {
      let selected = this.state.students.find((e) => e.id === id)
      this.setState({
        detailsFor : id,
        selectedStudent : selected
      })
    }
    this.reset = () => {
      this.setState({
        detailsFor : -1,
        selectedStudent : null
      })
    }
  }
  componentDidMount(){
    this.store.getAll()
    this.store.emitter.addListener('GET_ALL_SUCCESS', () => {
      this.setState({
        students : this.store.content
      })
    })
  }
  render() {
    if (this.state.detailsFor === -1){
      return (
        <div>
          {this.state.students.map((e, i) => <Student item={e} key={i} onDelete={this.delete} onSave={this.save} onSelect={this.select} />)}  
          <StudentForm onAdd={this.add} />
        </div>
      )
    }
    else{
      return (
        <StudentDetails item={this.state.selectedStudent} onExit={this.reset} />
      )
    }
  }
}

export default StudentList
