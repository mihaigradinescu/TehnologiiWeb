let sayHello = (name) => {
    console.warn(`Hello, ${name}`)    
}

sayHello('me')
